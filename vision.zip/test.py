import cv2


print(cv2.__version__)